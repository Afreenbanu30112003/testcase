package com.tns.customerService;

import org.springframework.data.jpa.repository.JpaRepository;

public interface customerRepository extends JpaRepository<customerEntity,Integer> {

}
