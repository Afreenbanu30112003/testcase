package com.tns.customerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class customerService {
	@Autowired
	private customerRepository service_repo;
	//to display all record from table
	public List<customerEntity>listAll(){
		return service_repo.findAll();
	
	}
	//to insert new record
	public void save(customerEntity s) {
		service_repo.save(s);
	}
	//to get the specific record
	public customerEntity get(Integer id) {
		return service_repo.findById(id).get();
	}
	//to delete the record
	public void delete(Integer id) {
		service_repo.deleteById(id);
	}

}
