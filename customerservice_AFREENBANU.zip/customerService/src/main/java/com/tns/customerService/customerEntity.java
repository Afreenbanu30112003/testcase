package com.tns.customerService;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="customer")
public class customerEntity {
	@Id
	@Column(name="cid")
	private int cid;
	@Column(name="cname")
	private String cname;
	@Column(name="dob")
	private int dob;
	@Column(name="phone_number")
	private int phone_number;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getDob() {
		return dob;
	}
	public void setDob(int dob) {
		this.dob = dob;
	}
	public int getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(int phone_number) {
		this.phone_number = phone_number;
	}
	//generate constructor
	public customerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public customerEntity(int cid, String cname, int dob, int phone_number) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.dob = dob;
		this.phone_number = phone_number;
	}
	//to string methods
	@Override
	public String toString() {
		return "customerEntity [cid=" + cid + ", cname=" + cname + ", dob=" + dob + ", phone_number=" + phone_number
				+ "]";
	}
	
	

}
//Getter and Setter methods
