package com.tns.customerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class customercontroller {
	@Autowired
	private customerService  service;
	@PostMapping("/customerService")
	public void add(@RequestBody customerEntity s) {
		service.save(s);
	}
	@GetMapping("/customerService")
	public List<customerEntity>listAll(){
		return service.listAll();
	}
	@DeleteMapping("/customerService")
		public void delete(@PathVariable Integer id) {
			service.delete(id);
		}
	}


